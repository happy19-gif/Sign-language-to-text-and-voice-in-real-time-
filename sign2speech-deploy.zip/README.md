# Sign2Speech — Real-time Sign Language → Text & Voice

A browser-based computer-vision app that watches your webcam, tracks your hand with
MediaPipe, classifies signs (static poses **and** movement), and turns them into
written text and spoken audio — live. The whole app is also **operated by hand
gestures**: no mouse required.

## Run it

```bash
cd sign2speech
python3 server.py
# open http://localhost:8000
```

(Any static file server works — the included one just sets the right MIME type for `.wasm`.)

Click **📷 Enable camera & start signing**, allow webcam access, and sign.

## What it does

- **Hand tracking** — MediaPipe Hands (21 landmarks/hand) runs locally in your browser via WebAssembly. No video ever leaves your device.
- **Classification beyond single frames** — every sign must be detected stably for ~0.5 s (8 frames) before it commits; a temporal smoother kills flicker. Control gestures require ~1.2 s holds.
- **Movement, not just poses** — a 1.3 s motion window detects *waving* (HELLO) and *forward movement* (THANK YOU), not just static shapes.
- **Text + voice** — recognized letters build words; words go straight to the transcript. Voice output uses the Web Speech API. Toggle 🔊 Voice to auto-speak each word, or use the 👌 gesture / 🔊 Speak button to read the whole sentence.
- **Hand-operated UI** — ☝️ point = space/commit word · ✊ fist = clear · 👌 OK = speak aloud.

## Sign catalogue

| Sign | Result | Type |
|---|---|---|
| Letters B, I, L, R, U, V, W, Y | spell words | letter (~0.5 s hold) |
| 👍 / 👎 | YES / NO | word |
| 🤟 (thumb + index + pinky) | I LOVE YOU | word |
| 👋 wave an open hand | HELLO | motion word |
| 🙏 flat hand moving toward camera | THANK YOU | motion word |
| ☝️ index finger (hold 1.2 s) | space / commit word | control |
| ✊ closed fist (hold 1.2 s) | clear transcript | control |
| 👌 OK sign (hold 1.2 s) | speak transcript aloud | control |

Keyboard fallback: Enter = speak · Space = commit word · Backspace = clear.

## How it works

1. Webcam frames → MediaPipe Hands (WASM) → 21 3D landmarks per frame.
2. `gestures.js` turns landmarks into geometric features (finger extension ratios, thumb pose, pinch distance, fingertip spread, palm size).
3. A rule-based classifier maps features → gesture id; a motion tracker adds temporal features (oscillation count, travel range, palm-size growth).
4. `app.js` smooths detections over time, commits gestures, maintains the transcript, draws the skeleton overlay, and speaks via `speechSynthesis`.

## Tuning

- Hold frames: `LETTER_HOLD` / `CONTROL_HOLD` at the top of `app.js`.
- Motion window: `new S2S.MotionTracker(1300)` (ms).
- Shape thresholds: `classify()` / `features()` in `gestures.js`.
- Model accuracy/speed: `modelComplexity` in `app.js` (0 = fastest, 1 = balanced, 2 = most accurate).
- A **Debug** checkbox under the video shows live features per frame.

## Tips for good recognition

- Bright, even lighting on your hand; avoid strong backlight.
- Keep the hand 40–80 cm from the camera, fully inside the frame.
- Hold each sign steady until it commits (watch the progress bar under the video).
- To repeat a letter, lower your hand briefly, then sign it again.

## Limitations

- Single hand, one sign at a time; letters + a few words (B I L R U V W Y).
- Subtle letters (A/S/T/C/O/F…) are intentionally mapped to controls or skipped to avoid false triggers — extend `GESTURES`/`classify()` to add more.
- Quality depends on lighting, camera, and skin/background contrast.

## Privacy

All processing happens locally in your browser. No frames, text, or audio are uploaded anywhere.
