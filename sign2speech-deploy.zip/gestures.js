/*
 * Sign2Speech — gesture engine.
 * Turns MediaPipe 21-landmark hand poses into letters, words and app-control
 * gestures, plus temporal motion analysis (wave / forward movement).
 * Heuristic + temporal: no extra neural net on top of the hand tracker.
 */
(function (global) {
  'use strict';

  // Landmark indices (MediaPipe Hands)
  const TIP = { thumb: 4, index: 8, middle: 12, ring: 16, pinky: 20 };
  const PIP = { index: 6, middle: 10, ring: 14, pinky: 18 };
  const MCP = { thumb: 2, index: 5, middle: 9, ring: 13, pinky: 17 };
  const FINGERS = ['index', 'middle', 'ring', 'pinky'];

  function d(a, b) {
    const dx = a.x - b.x, dy = a.y - b.y, dz = (a.z || 0) - (b.z || 0);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  function handSize(lm) { return d(lm[0], lm[MCP.middle]) || 1e-6; }

  /* ---------------- motion tracker (temporal features) ---------------- */
  class MotionTracker {
    constructor(windowMs) { this.windowMs = windowMs || 1300; this.pts = []; }

    push(t, cx, cy, size) {
      if (cx == null) { this.pts.length = 0; return; } // hand lost → reset window
      this.pts.push({ t, cx, cy, size });
      const cut = t - this.windowMs;
      while (this.pts.length && this.pts[0].t < cut) this.pts.shift();
    }

    analyze() {
      const out = { hello: false, thanks: false, signChanges: 0, xRange: 0, yRange: 0, sizeGrow: 1 };
      const pts = this.pts;
      if (pts.length < 12) return out;
      let flips = 0, prevSign = 0, minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
      for (let i = 1; i < pts.length; i++) {
        const dx = pts[i].cx - pts[i - 1].cx;
        if (Math.abs(dx) > 0.004) {
          const s = Math.sign(dx);
          if (prevSign !== 0 && s !== prevSign) flips++;
          prevSign = s;
        }
        if (pts[i].cx < minX) minX = pts[i].cx;
        if (pts[i].cx > maxX) maxX = pts[i].cx;
        if (pts[i].cy < minY) minY = pts[i].cy;
        if (pts[i].cy > maxY) maxY = pts[i].cy;
      }
      out.signChanges = flips;
      out.xRange = maxX - minX;
      out.yRange = maxY - minY;
      out.sizeGrow = pts[pts.length - 1].size / Math.max(pts[0].size, 1e-6);
      // HELLO: open hand waved side to side (≥3 direction flips, mostly horizontal)
      out.hello = flips >= 3 && out.xRange > 0.07 && out.yRange < 0.10;
      // THANK YOU: flat hand moving toward the camera (palm appears to grow)
      out.thanks = out.sizeGrow > 1.22 && out.xRange < 0.06 && out.yRange < 0.12;
      return out;
    }
  }

  /* ---------------- gesture catalogue ---------------- */
  const GESTURES = {
    B:      { kind: 'letter',  name: 'B',          label: 'Letter B' },
    I:      { kind: 'letter',  name: 'I',          label: 'Letter I' },
    L:      { kind: 'letter',  name: 'L',          label: 'Letter L' },
    R:      { kind: 'letter',  name: 'R',          label: 'Letter R' },
    U:      { kind: 'letter',  name: 'U',          label: 'Letter U' },
    V:      { kind: 'letter',  name: 'V',          label: 'Letter V' },
    W:      { kind: 'letter',  name: 'W',          label: 'Letter W' },
    Y:      { kind: 'letter',  name: 'Y',          label: 'Letter Y' },
    YES:    { kind: 'word',    name: 'YES',        label: '👍 Yes',          emoji: '👍' },
    NO:     { kind: 'word',    name: 'NO',         label: '👎 No',           emoji: '👎' },
    ILY:    { kind: 'word',    name: 'I LOVE YOU', label: '🤟 I love you',   emoji: '🤟' },
    HELLO:  { kind: 'word',    name: 'HELLO',      label: '👋 Hello',        emoji: '👋', note: 'wave your open hand side to side' },
    THANKS: { kind: 'word',    name: 'THANK YOU',  label: '🙏 Thank you',    emoji: '🙏', note: 'flat hand moves toward the camera' },
    POINT:  { kind: 'control', name: 'Space', action: 'space', label: '☝️ Point', emoji: '☝️', note: 'index finger · hold ~1.2 s' },
    FIST:   { kind: 'control', name: 'Clear', action: 'clear', label: '✊ Fist',   emoji: '✊', note: 'closed fist · hold ~1.2 s' },
    OK:     { kind: 'control', name: 'Speak', action: 'speak', label: '👌 OK',     emoji: '👌', note: 'OK sign · hold ~1.2 s' },
  };

  const ORDER = ['B', 'I', 'L', 'R', 'U', 'V', 'W', 'Y', 'YES', 'NO', 'ILY', 'HELLO', 'THANKS', 'POINT', 'FIST', 'OK'];

  /* ---------------- per-frame geometric features ---------------- */
  function features(lm) {
    const hs = handSize(lm);
    const ext = {};
    for (const f of FINGERS) {
      // rotation-invariant "extended" test: tip far from knuckle vs. mid-segment length
      ext[f] = d(lm[TIP[f]], lm[MCP[f]]) > 1.25 * d(lm[PIP[f]], lm[MCP[f]]);
    }
    const thumbOut = d(lm[TIP.thumb], lm[MCP.thumb]) > 1.15 * d(lm[3], lm[MCP.thumb]);
    const thumbUp = lm[TIP.thumb].y < lm[MCP.thumb].y - 0.02;
    const thumbDown = lm[TIP.thumb].y > lm[MCP.thumb].y + 0.02;
    const pinch = d(lm[TIP.thumb], lm[TIP.index]) < 0.28 * hs;
    const anyFinger = FINGERS.some((f) => ext[f]);
    let spread = 0;
    for (let i = 0; i < FINGERS.length; i++)
      for (let j = i + 1; j < FINGERS.length; j++)
        spread = Math.max(spread, d(lm[TIP[FINGERS[i]]], lm[TIP[FINGERS[j]]]));
    const openHand = FINGERS.every((f) => ext[f]);
    const flatHand = openHand && !thumbOut && spread < 0.40 * hs;
    const sepIM = d(lm[TIP.index], lm[TIP.middle]) / hs;
    const crossed = (lm[TIP.index].x - lm[TIP.middle].x) * (lm[MCP.index].x - lm[MCP.middle].x) < 0;
    return { hs, ext, thumbOut, thumbUp, thumbDown, pinch, anyFinger, spread, openHand, flatHand, sepIM, crossed };
  }

  /* ---------------- per-frame classifier ---------------- */
  function classify(lm, motion) {
    const f = features(lm);

    // control: OK / pinch (thumb+index circle, three fingers up)
    if (f.pinch && f.ext.middle && f.ext.ring && f.ext.pinky) return 'OK';

    // motion words take priority over the static flat hand
    if (f.openHand && motion) {
      if (motion.hello) return 'HELLO';
      if (motion.thanks) return 'THANKS';
    }
    if (f.flatHand) return 'B';

    // I LOVE YOU: thumb + index + pinky
    if (f.thumbOut && f.ext.index && !f.ext.middle && !f.ext.ring && f.ext.pinky) return 'ILY';

    // index + middle only
    if (f.ext.index && f.ext.middle && !f.ext.ring && !f.ext.pinky) {
      if (f.crossed) return 'R';                       // crossed fingers
      if (!f.thumbOut) return f.sepIM > 0.45 ? 'V' : 'U'; // spread vs. together
      return null;                                      // index+middle+thumb: not in catalogue
    }

    // W: index + middle + ring
    if (f.ext.index && f.ext.middle && f.ext.ring && !f.ext.pinky && !f.thumbOut) return 'W';

    // index only → L (thumb out) or POINT control (thumb tucked)
    if (f.ext.index && !f.ext.middle && !f.ext.ring && !f.ext.pinky) {
      return f.thumbOut ? 'L' : 'POINT';
    }

    // pinky only → Y (thumb out) or I
    if (!f.ext.index && !f.ext.middle && !f.ext.ring && f.ext.pinky) {
      return f.thumbOut ? 'Y' : 'I';
    }

    // thumbs up / down
    if (f.thumbOut && !f.anyFinger) {
      if (f.thumbUp) return 'YES';
      if (f.thumbDown) return 'NO';
      return null; // fist with thumb to the side (A/S family): intentionally skipped
    }

    // closed fist → CLEAR control
    if (!f.anyFinger && !f.thumbOut) return 'FIST';

    return null;
  }

  global.Sign2Speech = { GESTURES, ORDER, MotionTracker, classify, features, handSize };
})(window);
