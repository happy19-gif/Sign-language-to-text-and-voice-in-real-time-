/* Sign2Speech — webcam loop, temporal smoothing, transcript, voice output. */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const video = $('cam');
  const canvas = $('overlay');
  const ctx = canvas.getContext('2d');
  const chip = $('gestureChip');
  const chipEmoji = $('chipEmoji');
  const chipName = $('chipName');
  const chipKind = $('chipKind');
  const holdFill = $('holdFill');
  const transcriptEl = $('transcript');
  const wordEl = $('wordNow');
  const toastEl = $('toast');
  const fpsEl = $('fps');
  const latEl = $('latency');
  const camChip = $('camChip');
  const modelChip = $('modelChip');
  const debugEl = $('debug');
  const S2S = window.Sign2Speech;

  const LETTER_HOLD = 8;    // stable frames before a letter/word commits (~0.5 s)
  const CONTROL_HOLD = 18;  // stable frames before a control gesture fires (~1.2 s)

  let transcript = '';
  let word = '';
  let voiceMode = true;
  let modelReady = false;
  let running = false;

  const motion = new S2S.MotionTracker(1300);
  let curId = null;
  let stable = 0;
  let committed = false;

  const HAND_CONNECTIONS = [
    [0, 1], [1, 2], [2, 3], [3, 4],
    [0, 5], [5, 6], [6, 7], [7, 8],
    [5, 9], [9, 10], [10, 11], [11, 12],
    [9, 13], [13, 14], [14, 15], [15, 16],
    [13, 17], [17, 18], [18, 19], [19, 20], [0, 17]
  ];

  /* ---------- voice (Web Speech API) ---------- */
  let voices = [];
  const loadVoices = () => { voices = window.speechSynthesis.getVoices(); };
  loadVoices();
  window.speechSynthesis.onvoiceschanged = loadVoices;

  function speak(text) {
    if (!text) return;
    try {
      window.speechSynthesis.resume();
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 1; u.pitch = 1;
      const v = voices.find((v) => /en/i.test(v.lang));
      if (v) u.voice = v;
      window.speechSynthesis.speak(u);
    } catch (e) { /* speech unsupported */ }
  }

  /* ---------- toast ---------- */
  let toastTimer = null;
  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 1500);
  }

  /* ---------- transcript model ---------- */
  function render() {
    transcriptEl.textContent = transcript;
    transcriptEl.classList.toggle('empty', !transcript);
    wordEl.textContent = word ? '✍️ ' + word : '';
    $('speakBtn').disabled = !(transcript + word).trim();
    $('clearBtn').disabled = !(transcript + word).trim();
  }

  function flushWord() {
    if (word) { transcript += word + ' '; word = ''; }
  }

  function clearAll() {
    transcript = ''; word = '';
    render();
    toast('🗑 Cleared');
  }

  function speakAll() {
    const text = (transcript + word).trim();
    if (!text) { toast('Nothing to say yet'); return; }
    speak(text);
    toast('🔊 Speaking…');
  }

  /* ---------- commit actions ---------- */
  function commit(id) {
    const g = S2S.GESTURES[id];
    if (!g) return;
    if (g.kind === 'letter') {
      word += g.name;
      toast('✍️ ' + word);
    } else if (g.kind === 'word') {
      flushWord();
      transcript += g.name + ' ';
      if (voiceMode) speak(g.name);
      toast((g.emoji || '') + ' ' + g.name);
    } else if (g.action === 'space') {
      flushWord();
      toast('␣ Space — word saved');
    } else if (g.action === 'clear') {
      clearAll();
    } else if (g.action === 'speak') {
      speakAll();
    }
    render();
  }

  const requiredFrames = (id) =>
    S2S.GESTURES[id] && S2S.GESTURES[id].kind === 'control' ? CONTROL_HOLD : LETTER_HOLD;

  /* ---------- skeleton overlay ---------- */
  function drawHand(lm) {
    const W = canvas.width, H = canvas.height;
    const px = (p) => ({ x: (1 - p.x) * W, y: p.y * H }); // mirror to match selfie view
    ctx.lineWidth = Math.max(2, W / 140);
    ctx.strokeStyle = 'rgba(94, 234, 212, 0.85)';
    for (const [a, b] of HAND_CONNECTIONS) {
      const p1 = px(lm[a]), p2 = px(lm[b]);
      ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke();
    }
    const r = Math.max(3, W / 200);
    for (const p of lm) {
      const q = px(p);
      ctx.beginPath(); ctx.arc(q.x, q.y, r, 0, Math.PI * 2);
      ctx.fillStyle = '#0b1020'; ctx.fill();
      ctx.strokeStyle = '#5eead4'; ctx.stroke();
    }
  }

  /* ---------- per-frame results ---------- */
  const frameTimes = [];
  function onResults(results) {
    const now = performance.now();
    frameTimes.push(now);
    while (frameTimes.length && now - frameTimes[0] > 1000) frameTimes.shift();
    fpsEl.textContent = frameTimes.length + ' fps';

    const [sw, sh] = sourceSize();
    if (canvas.width !== sw || canvas.height !== sh) { canvas.width = sw; canvas.height = sh; }
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (source.tagName !== 'VIDEO') {
      // still image: paint it ourselves, mirrored to match selfieMode landmarks
      ctx.save(); ctx.scale(-1, 1); ctx.drawImage(source, -sw, 0, sw, sh); ctx.restore();
    }

    let lm = null;
    if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
      lm = results.multiHandLandmarks[0];
      drawHand(lm);
      const cx = (lm[0].x + lm[5].x + lm[9].x + lm[13].x + lm[17].x) / 5;
      const cy = (lm[0].y + lm[5].y + lm[9].y + lm[13].y + lm[17].y) / 5;
      motion.push(now, cx, cy, S2S.handSize(lm));
    } else {
      motion.push(now, null, null, null);
    }

    const m = motion.analyze();
    const id = lm && modelReady ? S2S.classify(lm, m) : null;

    // temporal smoothing: a label must persist before it commits
    if (id === curId) stable += 1;
    else { curId = id; stable = 1; committed = false; }

    const req = id ? requiredFrames(id) : 0;
    holdFill.style.width = req ? Math.min(100, (stable / req) * 100) + '%' : '0%';

    if (id) {
      const g = S2S.GESTURES[id];
      chip.className = 'gesture-chip show ' + g.kind;
      chipEmoji.textContent = g.kind === 'letter' ? g.name : (g.emoji || '');
      chipName.textContent = g.kind === 'letter' ? g.label : g.name;
      chipKind.textContent =
        g.kind === 'control' ? 'CONTROL · keep holding' :
        g.kind === 'word' ? 'WORD · hold' : 'LETTER · hold';
      if (!committed && stable >= req) { commit(id); committed = true; }
    } else {
      chip.className = 'gesture-chip';
      chipEmoji.textContent = '';
      chipName.textContent = '—';
      chipKind.textContent = 'show a sign to the camera';
    }

    if ($('debugToggle').checked && lm) {
      debugEl.classList.remove('hidden');
      debugEl.textContent = JSON.stringify(
        { id, stable, ...S2S.features(lm), ...m },
        (k, v) => (typeof v === 'number' ? +v.toFixed(3) : v), 1);
    } else {
      debugEl.classList.add('hidden');
    }
  }

  /* ---------- input sources + model ---------- */
  let hands = null;          // MediaPipe instance (created once)
  let source = video;        // element currently fed to the model: webcam <video>, file <video>, or <img>
  let stream = null;         // active webcam stream, if any
  let loopToken = 0;

  async function initModel() {
    if (hands) return hands;
    modelChip.textContent = '● Loading model…';
    const h = new Hands({ locateFile: (f) => 'vendor/hands/' + f });
    h.setOptions({
      maxNumHands: 1,
      modelComplexity: 1,
      minDetectionConfidence: 0.6,
      minTrackingConfidence: 0.6,
      selfieMode: true,
    });
    h.onResults(onResults);
    try {
      await h.initialize();
    } catch (e) {
      modelChip.textContent = '● Model failed';
      modelChip.classList.add('bad');
      toast('Could not load the hand model');
      throw e;
    }
    hands = h;
    modelReady = true;
    modelChip.textContent = '● Model ready';
    modelChip.classList.add('ok');
    return h;
  }

  function setCamChip(text, cls) {
    camChip.textContent = text;
    camChip.classList.remove('ok', 'bad');
    if (cls) camChip.classList.add(cls);
  }

  function stopStream() {
    if (stream) { stream.getTracks().forEach((t) => t.stop()); stream = null; }
  }

  function cameraBlockReason(e) {
    const name = e && e.name ? e.name : '';
    const inFrame = window.self !== window.top;
    let policyBlocked = false;
    try {
      const pp = document.permissionsPolicy || document.featurePolicy;
      if (pp && typeof pp.allowsFeature === 'function') policyBlocked = !pp.allowsFeature('camera');
    } catch (_) { /* ignore */ }
    if (!window.isSecureContext) return ['Camera needs a secure page (HTTPS or localhost).', 'InsecureContext'];
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return ['This browser cannot access the camera here.', 'NoMediaDevices'];
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return ['No webcam was found. Plug one in and click Retry.', name];
    if (name === 'NotReadableError' || name === 'TrackStartError') return ['The webcam is in use by another app. Close it and click Retry.', name];
    if (policyBlocked || (inFrame && name === 'NotAllowedError'))
      return ['The page embedding this preview does not allow camera access. Open the app in its own tab, or try a sample image below.', 'BlockedByEmbedPolicy'];
    if (name === 'NotAllowedError') return ['Camera access was blocked. Click the camera icon in the address bar, choose "Allow", then click Retry.', name];
    return ['Could not start the camera.', name || 'Unknown'];
  }

  async function start() {
    $('startOverlay').classList.add('hidden');
    setCamChip('● Camera', 'ok');
    stopStream();
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
        audio: false,
      });
    } catch (e) {
      const [msg, code] = cameraBlockReason(e);
      setCamChip('● Camera denied', 'bad');
      $('startOverlay').classList.remove('hidden');
      $('startBtn').textContent = '📷 Retry camera';
      $('startMsg').textContent = msg + ' (' + code + ')';
      const link = $('openTab');
      if (link) { link.href = window.location.href; link.classList.toggle('hidden', window.self === window.top); }
      return;
    }
    video.pause();
    video.removeAttribute('src');
    video.loop = false;
    video.srcObject = stream;
    video.classList.remove('hidden');
    await video.play().catch(() => {});
    source = video;
    try { await initModel(); } catch (_) { return; }
    runLoop();
  }

  async function startImage(url, label) {
    stopStream();
    const img = new Image();
    img.src = url;
    try { await img.decode(); } catch (_) { toast('Could not load that image'); return; }
    $('startOverlay').classList.add('hidden');
    video.pause();
    video.srcObject = null;
    video.classList.add('hidden');
    source = img;
    setCamChip('● ' + (label || 'Image'), 'ok');
    try { await initModel(); } catch (_) { return; }
    runLoop();
  }

  async function startVideoFile(url, label) {
    stopStream();
    $('startOverlay').classList.add('hidden');
    video.srcObject = null;
    video.src = url;
    video.loop = true;
    video.muted = true;
    video.classList.remove('hidden');
    await video.play().catch(() => {});
    source = video;
    setCamChip('● ' + (label || 'Video file'), 'ok');
    try { await initModel(); } catch (_) { return; }
    runLoop();
  }

  function sourceReady() {
    if (source.tagName === 'VIDEO') return source.readyState >= 2 && source.videoWidth > 0;
    return source.complete && source.naturalWidth > 0;
  }

  function sourceSize() {
    return source.tagName === 'VIDEO'
      ? [source.videoWidth || 640, source.videoHeight || 480]
      : [source.naturalWidth || 640, source.naturalHeight || 480];
  }

  function runLoop() {
    running = true;
    const token = ++loopToken;
    (async () => {
      while (running && token === loopToken) {
        if (sourceReady()) {
          const t0 = performance.now();
          try { await hands.send({ image: source }); } catch (e) { /* transient */ }
          latEl.textContent = Math.round(performance.now() - t0) + ' ms';
        }
        await new Promise((r) => requestAnimationFrame(r));
      }
    })();
  }

  /* ---------- UI wiring ---------- */
  function buildRef() {
    const grid = $('refGrid');
    for (const id of S2S.ORDER) {
      const g = S2S.GESTURES[id];
      const el = document.createElement('div');
      el.className = 'ref-item ' + g.kind;
      el.innerHTML = g.kind === 'letter'
        ? '<span class="ref-emoji letter-badge">' + g.name + '</span><span class="ref-name">' + g.label + '</span>'
        : '<span class="ref-emoji">' + g.emoji + '</span><span class="ref-name">' + g.name + (g.note ? '<small>' + g.note + '</small>' : '') + '</span>';
      grid.appendChild(el);
    }
  }

  $('startBtn').addEventListener('click', start);
  $('speakBtn').addEventListener('click', speakAll);

  document.querySelectorAll('[data-sample]').forEach((b) => {
    b.addEventListener('click', () => startImage(b.getAttribute('data-sample'), 'Sample ' + b.textContent.trim().split(/\s+/)[0]));
  });
  const fileIn = $('fileInput');
  if (fileIn) {
    fileIn.addEventListener('change', () => {
      const f = fileIn.files && fileIn.files[0];
      if (!f) return;
      const url = URL.createObjectURL(f);
      if (f.type.startsWith('video/')) startVideoFile(url, f.name);
      else startImage(url, f.name);
      fileIn.value = '';
    });
  }
  const camBtn = $('useCamBtn');
  if (camBtn) camBtn.addEventListener('click', start);

  // Auto-enable the camera on load (the browser will prompt once; after that it starts instantly).
  window.addEventListener('load', () => {
    if (!running && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) start();
  });
  $('clearBtn').addEventListener('click', clearAll);
  $('voiceToggle').addEventListener('change', (e) => {
    voiceMode = e.target.checked;
    toast(voiceMode ? '🔊 Voice on' : '🔇 Voice off');
  });

  window.addEventListener('keydown', (e) => {
    if (e.target && e.target.tagName === 'INPUT') return;
    if (e.key === 'Enter') speakAll();
    else if (e.key === 'Backspace') clearAll();
    else if (e.key === ' ') { e.preventDefault(); flushWord(); render(); }
  });

  buildRef();
  render();
})();
